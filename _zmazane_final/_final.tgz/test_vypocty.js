// Výpočtové testy k auditu 2026-08-18 (nálezy B1–B6). Beh: node test_vypocty.js
// Očakávané hodnoty sú KONKRÉTNE čísla z auditu — každý test padne na kóde spred opravy.
const assert = require("assert");
const { load } = require("./test_harness");

const app = load({ stav: {} });
const g = (nazov, mnozstvo, jednotka) => {
  const p = app.najdiPotravinu(nazov);
  return app.gramy({ nazov, mnozstvo, jednotka }, p);
};
const ing = (id, vzor) => {
  const r = app.receptById(id);
  assert.ok(r, "recept neexistuje: " + id);
  const i = (r.ingrediencie || []).find(x => vzor.test(x.nazov));
  assert.ok(i, "ingrediencia " + vzor + " nie je v " + id);
  return i;
};

let bezov = 0;
function ok(popis, fn) { fn(); console.log("  ✓ " + popis); bezov++; }

// ─────────────────────────────────────────────────────────── B2: „ks" bez hmotnosti
console.log("B2 — počítateľné jednotky bez g_za_ks (predtým paušál 60 g)");
ok("chicken-biryani: Kardamómy 4 ks ≤ 5 g (predtým 240 g)", () => {
  const i = ing("chicken-biryani", /ardam/i);
  const gr = app.gramy(i, app.najdiPotravinu(i.nazov));
  assert.ok(gr <= 5, "kardamómy = " + gr + " g");
});
ok("borsc: 3 bobkové listy nesmú nafúknuť kcal (60 g/ks by dalo +141 kcal/porciu)", () => {
  const k = app.kcalPorcia(app.receptById("borsc"));
  assert.ok(k <= 300, "borsc = " + k + " kcal");
});
ok("grilovane-jalapeno: 14 plátkov slaniny ≤ 400 g (predtým 840 g)", () => {
  const i = ing("grilovane-jalapeno-syr-slanina", /slanin/i);
  const gr = app.gramy(i, app.najdiPotravinu(i.nazov));
  assert.ok(gr > 0 && gr <= 400, "slanina = " + gr + " g");
});
ok("bobkový list 3 ks ≤ 1 g (predtým 180 g)", () => {
  const gr = g("Bobkový list", 3, "ks");
  assert.ok(gr > 0 && gr <= 1, "bobkový list = " + gr + " g");
});
ok("neznáma hmotnosť kusa → 0 g a príznak „≈ odhad\"", () => {
  const fake = { nazov: "Vymyslená surovina", mnozstvo: 2, jednotka: "ks" };
  assert.strictEqual(app.gramy(fake, { kluc: "x", hustota: 1 }), 0);
  const r = { id: "_t", nazov: "T", porcie: 1, ingrediencie: [{ nazov: "Sezam", mnozstvo: 3, jednotka: "ks" }] };
  assert.ok(app.vyzivaReceptu(r).pribl, "recept s nedopočítanou surovinou musí byť označený ako odhad");
});

// ─────────────────────────────────────────────────────────── B3: KS_DEF vs g_za_ks
console.log("\nB3 — jednotka listu/plátku/strúčika sa už neráta ako celý kus");
ok("„Šalát 4 list“ ≤ 60 g (predtým 1200 g = 4 hlávky)", () => {
  const gr = g("Hlávkový šalát", 4, "list");
  assert.ok(gr > 0 && gr <= 60, "šalát = " + gr + " g");
});
ok("tortilla-wrap-sunka-eidam: 463 → ≤ 425 kcal/porcia (dekl. 397)", () => {
  const k = app.kcalPorcia(app.receptById("tortilla-wrap-sunka-eidam"));
  assert.ok(k <= 425, "wrap = " + k + " kcal");
});
ok("„Šalátové listy 2 hrsť“ = 60 g, „Bazalka 24 lístok“ = 24 g", () => {
  assert.strictEqual(g("Šalátové listy", 2, "hrsť"), 60);
  assert.strictEqual(g("Bazalka", 24, "lístok"), 24);
});
ok("plátok má vlastnú hmotnosť: toastový chlieb 2 plátky = 56 g, nori 1 plátok = 3 g", () => {
  assert.strictEqual(g("Toastový chlieb", 2, "plátok"), 56);
  assert.strictEqual(g("Nori riasa", 1, "plátok"), 3);
});
ok("gramyNaJed je inverzná ku gramy (g, ml, ks, strúčik, plátok, list)", () => {
  const vzorky = [
    ["Cesnak", 8, "strúčik"], ["Hlávkový šalát", 4, "list"], ["Toastový chlieb", 2, "plátok"],
    ["Vajce", 3, "ks"], ["Ryža", 250, "g"], ["Mlieko", 200, "ml"], ["Cesnak", 1, "strúčik"],
  ];
  vzorky.forEach(([nazov, mn, jed]) => {
    const p = app.najdiPotravinu(nazov);
    const gr = app.gramy({ nazov, mnozstvo: mn, jednotka: jed }, p);
    assert.ok(gr > 0, nazov + " " + mn + " " + jed + " → 0 g");
    const spat = app.gramyNaJed(gr, jed, p);
    assert.ok(Math.abs(spat - mn) < 1e-9, nazov + ": " + mn + " " + jed + " → " + gr + " g → " + spat + " " + jed);
  });
});

// ─────────────────────────────────────────────────────────── B1: párovanie surovín
console.log("\nB1 — párovanie surovín na potraviny.json (skloňovanie a modifikátory)");
ok("„Kokosového mlieka 400 ml“ → 197 kcal/100 g a ~2,00 € (predtým 660 kcal / 8,00 €)", () => {
  const p = app.najdiPotravinu("Kokosového mlieka");
  assert.ok(p, "kokosové mlieko sa nenapárovalo");
  assert.ok(p.kcal <= 250, "kcal/100 g = " + p.kcal + " (kľúč " + p.kluc + ")");
  const gr = app.gramy({ nazov: "Kokosového mlieka", mnozstvo: 400, jednotka: "ml" }, p);
  const cena = gr / 100 * (p.cena100 || 0);
  assert.ok(cena > 0.5 && cena < 3.5, "400 ml stojí " + cena.toFixed(2) + " €");
});
ok("„Maslová tekvica 300 g“ ≤ 200 kcal (predtým 2151 — párovalo sa na maslo)", () => {
  const p = app.najdiPotravinu("Maslová tekvica");
  assert.ok(p, "maslová tekvica sa nenapárovala");
  assert.ok(3 * p.kcal <= 200, "300 g = " + 3 * p.kcal + " kcal (kľúč " + p.kluc + ")");
});
ok("„Olej na opekanie“ → olej, nie pekanový orech (o-PEKAN-ie)", () => {
  const p = app.najdiPotravinu("Olej na opekanie");
  assert.ok(p && /olej/.test(p.kluc), "napárované na " + (p && p.kluc));
});
ok("„Kokosová smotana“ nesmie mať alergén mlieko", () => {
  const p = app.najdiPotravinu("Kokosová smotana");
  assert.ok(p, "kokosová smotana sa nenapárovala");
  assert.ok(!(p.alergeny || []).includes("mlieko"), "kľúč " + p.kluc + " má alergény " + p.alergeny);
});
ok("„Vanilkový cukor 1 ks“ nestojí 3,20 €", () => {
  const p = app.najdiPotravinu("Vanilkový cukor");
  const gr = app.gramy({ nazov: "Vanilkový cukor", mnozstvo: 1, jednotka: "ks" }, p);
  const cena = gr / 100 * ((p && p.cena100) || 0);
  assert.ok(cena < 0.6, "1 ks vanilkového cukru = " + cena.toFixed(2) + " € (kľúč " + (p && p.kluc) + ")");
});
ok("„Kuracie stehná“ sa spárujú na kľúč „kuracie steh“ (nie na „kura“)", () => {
  for (const n of ["Kuracie stehná", "Kuracích stehien", "Vykostené kuracie stehná"]) {
    const p = app.najdiPotravinu(n);
    assert.ok(p && p.kluc === "kuracie steh", n + " → " + (p && p.kluc));
  }
});
ok("„Kondenzované mlieko“ nie je obyčajné mlieko (64 kcal)", () => {
  const p = app.najdiPotravinu("Kondenzované mlieko");
  assert.ok(p && p.kcal > 200, "kondenzované mlieko = " + (p && p.kcal) + " kcal (kľúč " + (p && p.kluc) + ")");
});
ok("„Krabie mäso 200 g“ má cenu", () => {
  const p = app.najdiPotravinu("Krabie mäso");
  assert.ok(p && p.cena100 > 0, "krabie mäso: kľúč " + (p && p.kluc) + ", cena " + (p && p.cena100));
});
ok("nepotravina „Špáradlá“ zmizla z ingrediencií", () => {
  const zle = app.RECEPTY.filter(r => (r.ingrediencie || []).some(i => /špáradl|sparadl/i.test(i.nazov)));
  assert.strictEqual(zle.length, 0, "ešte v: " + zle.map(r => r.id).join(", "));
});
ok("22 predtým nenapárovaných surovín (Krupica, Ementál, Bucatini…) sa páruje", () => {
  ["Krupica", "Ementál", "Sušené hríby", "Lístkové cesto", "Lasagne pláty", "Bucatini",
   "Tzatziki", "Balzamikový krém", "Paradajkový pretlak"].forEach(n => {
    assert.ok(app.najdiPotravinu(n), n + " sa stále nepáruje");
  });
});

// ─────────────────────────────────────────────────────────── B5: chýbajúce ceny
console.log("\nB5 — ceny potravín");
ok("žiadna potravina nemá neznámu cenu (predtým 27 z 478)", () => {
  const bez = app.POTRAVINY.filter(p => p.cena100 == null).map(p => p.kluc);
  assert.strictEqual(bez.length, 0, "bez ceny: " + bez.join(", "));
});
ok("v týždennom pláne 2 stravníkov nie je položka nákupu s cenou 0,00 €", () => {
  const S = app.S;
  S.viewOd = "2026-08-17";
  S.hranice = [true, false, true, false, false, true, false];
  S.blokMode = true;
  S.profil.stravnici = [{ nazov: "A", kcal: 1450 }, { nazov: "B", kcal: 1450 }];
  S.plan = {}; S.planF = {};
  // deterministický plán: prvých 28 receptov s ingredienciami do slotov týždňa
  const zoz = app.RECEPTY.filter(r => (r.ingrediencie || []).some(i => i.mnozstvo != null)).slice(0, 28);
  let k = 0;
  for (let di = 0; di < 7; di++) {
    const iso = app.datumPre(di); S.plan[iso] = {};
    ["Raňajky", "Obed", "Večera", "Snack"].forEach(sl => { S.plan[iso][sl] = [zoz[k++ % zoz.length].id]; });
  }
  const rows = app.nakupItems().filter(r => r.gkey);
  const nezname = rows.filter(r => r.bezCeny);
  assert.strictEqual(nezname.length, 0, "neznáma cena: " + nezname.map(r => r.nazov).join(", "));
  // jediná legitímna nula je voda z vodovodu — všetko ostatné musí mať cenu
  const nulove = rows.filter(r => !(r.cena > 0) && !/vod[au]?$/i.test(r.nazov.trim()));
  assert.strictEqual(nulove.length, 0, "nulová cena: " + nulove.map(r => r.nazov).join(", "));
  S.plan = {}; S.planF = {};
});
ok("recept s nedopočítanou cenou to vie priznať (v.bezCeny)", () => {
  const r = { id: "_c", nazov: "C", porcie: 1, ingrediencie: [{ nazov: "Ryža", mnozstvo: 100, jednotka: "g" }] };
  assert.strictEqual(app.vyzivaReceptu(r).bezCeny, 0);
  const r2 = { id: "_c2", nazov: "C2", porcie: 1, ingrediencie: [{ nazov: "Neznáma vec xyz", mnozstvo: 100, jednotka: "g" }] };
  assert.ok(app.vyzivaReceptu(r2).bezCeny > 0, "nenapárovaná surovina sa má rátať ako chýbajúca cena");
});

// ─────────────────────────────────────────────────────────── B6: vláknina a sodík
console.log("\nB6 — vláknina a sodík");
ok("sójová omáčka prispieva ~5500 mg Na/100 g (predtým 0)", () => {
  const p = app.najdiPotravinu("Sójová omáčka");
  assert.ok(p && p.sodik > 4000, "sójová omáčka: " + (p && p.sodik) + " mg Na/100 g");
});
ok("týždeň so sójovou omáčkou ukáže sodík > 2000 mg/deň (predtým 1274)", () => {
  const S = app.S;
  S.viewOd = "2026-08-17";
  S.plan = {}; S.planF = {};
  const sojove = app.RECEPTY.filter(r => (r.ingrediencie || []).some(i => /sójov[aá] omáčk/i.test(i.nazov)));
  assert.ok(sojove.length >= 7, "málo receptov so sójovou omáčkou: " + sojove.length);
  let k = 0, sodikDni = [];
  for (let di = 0; di < 7; di++) {
    const iso = app.datumPre(di); S.plan[iso] = {};
    ["Raňajky", "Obed", "Večera", "Snack"].forEach(sl => { S.plan[iso][sl] = [sojove[k++ % sojove.length].id]; });
    let na = 0;
    app.slotyDna(di).forEach(sl => app.slotIds(di, sl).forEach(cid => { na += app.vyzivaReceptu(app.komponent(cid)).na || 0; }));
    sodikDni.push(na);
  }
  const priemer = sodikDni.reduce((a, x) => a + x, 0) / 7;
  assert.ok(priemer > 2000, "sodík = " + Math.round(priemer) + " mg/deň");
  S.plan = {}; S.planF = {};
});
ok("vyzivaReceptu hlási pokrytie hmoty údajmi (v.hmota / v.hmotaNa)", () => {
  const r = { id: "_p", nazov: "P", porcie: 1, ingrediencie: [{ nazov: "Ryža", mnozstvo: 100, jednotka: "g" }] };
  const v = app.vyzivaReceptu(r);
  assert.ok(v.hmota > 0, "hmota sa neráta");
  assert.ok(v.hmotaNa / v.hmota > 0.99, "ryža má známy sodík, pokrytie má byť 100 %");
  const r2 = { id: "_p2", nazov: "P2", porcie: 1,
    ingrediencie: [{ nazov: "Ryža", mnozstvo: 100, jednotka: "g" }, { nazov: "Zázračná zmes", mnozstvo: 100, jednotka: "g" }] };
  const v2 = app.vyzivaReceptu(r2);
  assert.ok(v2.hmotaNa / v2.hmota < 1, "nenapárovaná surovina má znížiť pokrytie");
});

// ─────────────────────────────────────── B7: vsiaknutie (olej na vyprážanie)
console.log("\nB7 — `vsiaknutie` zmenšuje VÝŽIVU, nie nákup ani cenu");
ok("kcal, makrá, vláknina a sodík klesnú presne o koeficient; cena a gramy zostanú", () => {
  const ing = { nazov: "Slnečnicový olej", mnozstvo: 500, jednotka: "ml" };
  const plny = app.vyzivaReceptu({ id: "_v1", nazov: "V", porcie: 1, ingrediencie: [{ ...ing }] });
  const s20 = app.vyzivaReceptu({ id: "_v2", nazov: "V", porcie: 1, ingrediencie: [{ ...ing, vsiaknutie: 0.2 }] });
  assert.ok(Math.abs(s20.kcal - plny.kcal * 0.2) < 1e-6, "kcal má klesnúť 5×");
  assert.ok(Math.abs(s20.t - plny.t * 0.2) < 1e-6, "tuky majú klesnúť 5×");
  assert.ok(Math.abs(s20.cena - plny.cena) < 1e-9, "cena musí zostať na plnom množstve (olej sa kupuje celý)");
  const p = app.najdiPotravinu(ing.nazov);
  assert.strictEqual(app.gramy({ ...ing, vsiaknutie: 0.2 }, p), app.gramy(ing, p), "gramy() sa nesmie meniť");
});
ok("neplatné alebo chýbajúce `vsiaknutie` = 1 (pôvodné správanie)", () => {
  [undefined, null, "0.2", -1, 2, NaN].forEach(v => {
    assert.strictEqual(app.vsiaknuteho({ nazov: "x", vsiaknutie: v }), 1, "vsiaknutie=" + v);
  });
  assert.strictEqual(app.vsiaknuteho({ nazov: "x", vsiaknutie: 0.25 }), 0.25);
  assert.strictEqual(app.vsiaknuteho({ nazov: "x", vsiaknutie: 0 }), 0);
});
ok("nákupný zoznam kupuje PLNÉ množstvo označenej suroviny", () => {
  const a2 = load({ seed: 7, stav: { viewOd: "2026-08-17",
    plan: { "2026-08-17": { "Obed": "musaka" } },
    profil: { osoby: 1, kcal: 1450, stravnici: [{ nazov: "A", kcal: 1450 }] } } });
  const { grp } = a2.nakupPolozky();
  const olej = Object.values(grp).find(G => /slnečnicový olej/i.test(G.nazov));
  assert.ok(olej, "olej z musaky musí byť v nákupe");
  const r = a2.receptById("musaka");
  const i = r.ingrediencie.find(x => x.vsiaknutie != null);
  const p = a2.najdiPotravinu(i.nazov);
  const plne = a2.gramy(i, p) / (r.porcie || 1);      // na 1 porciu v pláne
  assert.ok(olej.grams > plne * 0.9, "do nákupu ide plné množstvo, nie vsiaknuté (" +
    Math.round(olej.grams) + " g vs " + Math.round(plne) + " g)");
});

// ─────────────────────────────────────────────────────────── B4: kcal brzda
console.log("\nB4 — kurátorovanému kcal_na_porciu sa verí vždy");
ok("au-jus-sendvic-s-hovadzim zobrazí kurátorovaných 881 kcal (výpočet dá ~220)", () => {
  const r = app.receptById("au-jus-sendvic-s-hovadzim");
  assert.strictEqual(app.kcalPorcia(r), 881);
  assert.strictEqual(app.kcalPorcia(r), r.kcal_na_porciu);
});
ok("kuracie-nugetky zobrazia svoje deklarované kcal", () => {
  const r = app.receptById("kuracie-nugetky");
  assert.strictEqual(app.kcalPorcia(r), r.kcal_na_porciu);
});
ok("makrá a cena sa prepočítajú rovnakým faktorom, vláknina a sodík NIE", () => {
  const zaklad = { id: "_b", nazov: "B", porcie: 1,
    ingrediencie: [{ nazov: "Ryža", mnozstvo: 100, jednotka: "g" }] };
  const bez = app.vyzivaReceptu({ ...zaklad, kcal_na_porciu: 0 });
  // deklarácia vnútri pásma dôvery ⟨0,5; 2⟩ → plné preškálovanie ako doteraz
  const dekl = Math.round(bez.kcal * 0.8);
  const s = app.vyzivaReceptu({ ...zaklad, kcal_na_porciu: dekl });
  const k = dekl / bez.kcal;
  assert.strictEqual(s.kcal, dekl);
  assert.ok(Math.abs(s.b - bez.b * k) < 1e-9, "bielkoviny sa majú škálovať");
  assert.ok(Math.abs(s.cena - bez.cena * k) < 1e-9, "cena sa má škálovať");
  assert.ok(Math.abs(s.vl - bez.vl) < 1e-9, "vláknina sa NEMÁ škálovať");
  assert.ok(Math.abs(s.na - bez.na) < 1e-9, "sodík sa NEMÁ škálovať");
  assert.ok(!s.sporne, "rozdiel 20 % nie je sporný");
});
// ── B8: poistka na faktor mimo pásma ⟨0,5; 2⟩ ────────────────────────────────
ok("faktor mimo pásma sa zovrie a recept sa PRIZNÁ ako odhad (nie tiché preškálovanie)", () => {
  const zaklad = { id: "_k", nazov: "K", porcie: 1,
    ingrediencie: [{ nazov: "Ryža", mnozstvo: 100, jednotka: "g" }] };
  const bez = app.vyzivaReceptu({ ...zaklad, kcal_na_porciu: 0 });
  // deklarované 10× menej než suroviny (typ „hovädzí steak z 500 g krkovice, porcie: 1")
  const male = Math.round(bez.kcal / 10);
  const s = app.vyzivaReceptu({ ...zaklad, kcal_na_porciu: male });
  assert.strictEqual(s.kcal, male, "B4 platí ďalej — kcal je deklarovaná hodnota");
  assert.ok(s.sporne, "recept musí byť označený ako sporný");
  assert.ok(s.q > app.K_PASMO_HI, "q má byť nad horným okrajom pásma");
  const kZovrety = 1 / app.K_PASMO_HI;               // najviac 2× nadol
  assert.ok(Math.abs(s.b - bez.b * kZovrety) < 1e-9,
    "bielkoviny sa smú deliť najviac dvojkou, nie desiatkou (" + s.b.toFixed(2) + " g)");
  // opačný smer: deklarované 10× viac než suroviny (chýbajúce gramy)
  const velke = Math.round(bez.kcal * 10);
  const v = app.vyzivaReceptu({ ...zaklad, kcal_na_porciu: velke });
  assert.ok(v.sporne, "aj podstrelený dopočet musí byť označený ako sporný");
  assert.ok(Math.abs(v.b - bez.b / app.K_PASMO_LO) < 1e-9,
    "bielkoviny sa smú násobiť najviac dvojkou (" + v.b.toFixed(2) + " g)");
});
ok("rozdiel > 10 % je označený ako odhad, do 10 % nie", () => {
  const zaklad = { id: "_o", nazov: "O", porcie: 1, ingrediencie: [{ nazov: "Ryža", mnozstvo: 100, jednotka: "g" }] };
  const cistyKcal = app.vyzivaReceptu(zaklad).kcal;
  assert.ok(app.vyzivaReceptu({ ...zaklad, kcal_na_porciu: Math.round(cistyKcal * 0.5) }).pribl, "50 % rozdiel = odhad");
  assert.ok(!app.vyzivaReceptu({ ...zaklad, kcal_na_porciu: Math.round(cistyKcal * 0.98) }).pribl, "2 % rozdiel nie je odhad");
});
ok("recept bez kcal_na_porciu sa nezmenil (kcal je čistý súčet surovín)", () => {
  // väčšina receptov už kcal_na_porciu má (scripts/dopocitaj_kcal.js), preto testujeme na vlastnom
  const r = { id: "_bezdekl", nazov: "Bez deklarácie", porcie: 2,
    ingrediencie: [{ nazov: "Ryža", mnozstvo: 200, jednotka: "g" }, { nazov: "Olivový olej", mnozstvo: 20, jednotka: "g" }] };
  const v = app.vyzivaReceptu(r);
  let kc = 0;
  (r.ingrediencie || []).forEach(i => { const p = app.najdiPotravinu(i.nazov); if (p) kc += app.gramy(i, p) * p.kcal / 100; });
  assert.ok(Math.abs(v.kcal - kc / (r.porcie || 1)) < 1e-6, r.id + ": " + v.kcal + " vs " + kc / (r.porcie || 1));
});

console.log("\nOK — " + bezov + " kontrol prešlo.");
